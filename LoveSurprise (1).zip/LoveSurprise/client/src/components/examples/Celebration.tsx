import Celebration from "../Celebration";

export default function CelebrationExample() {
  return <Celebration />;
}
